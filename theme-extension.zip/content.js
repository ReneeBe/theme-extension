chrome.runtime.onMessage.addListener((t,i,n)=>{if(t.type!=="APPLY_THEME")return;const s=t.vars,o=`:root {
${Object.entries(s).map(([r,d])=>`  ${r}: ${d};`).join(`
`)}
}`;let e=document.getElementById("theme-extension-styles");e||(e=document.createElement("style"),e.id="theme-extension-styles",document.head.appendChild(e)),e.textContent=o,n({ok:!0})});
