function m(t){const o=t["--background"]??"#0a0a0a",e=t["--foreground"]??"#ffffff",i=t["--grad-a"]??t["--blob-1"]??"#7209b7",n=t["--grad-b"]??t["--blob-2"]??"#f72585",a=t["--glass-bg"]??"rgba(255,255,255,0.05)",s=t["--glass-border"]??"rgba(255,255,255,0.1)",d=t["--font-heading"]??"sans-serif",l=t["--font-body"]??"sans-serif",c=t["--bg-pattern"]??"none",g=`
:root { ${Object.entries(t).map(([f,b])=>`${f}: ${b};`).join(" ")} }
*,*::before,*::after { color: ${e} !important; background-color: transparent !important; border-color: ${s} !important; }
html,body { background-color: ${o} !important; font-family: ${l} !important; ${c!=="none"?`background-image: ${c} !important; background-size: cover !important; background-repeat: no-repeat !important;`:""} }
h1,h2,h3,h4,h5,h6 { font-family: ${d} !important; }
a { color: ${i} !important; }
a:hover { color: ${n} !important; }
button,[role="button"] { background: linear-gradient(135deg,${i},${n}) !important; color: #fff !important; }
input,textarea,select { background-color: ${a} !important; border: 1px solid ${s} !important; }
img,video,canvas,svg,iframe { background-color: transparent !important; filter: none !important; }`;let r=document.getElementById("theme-extension-styles");r||(r=document.createElement("style"),r.id="theme-extension-styles",document.head.appendChild(r)),r.textContent=g}(async()=>{const t=window.location.hostname;if(!t)return;const o=await chrome.storage.local.get(["savedThemes","siteThemes"]),e=o.savedThemes??[],n=(o.siteThemes??{})[t];if(!n)return;const a=e.find(s=>s.id===n);a&&m(a.vars)})();chrome.runtime.onMessage.addListener((t,o,e)=>{t.type==="APPLY_THEME"?(m(t.vars),e({ok:!0})):t.type==="REMOVE_THEME"&&(document.getElementById("theme-extension-styles")?.remove(),e({ok:!0}))});
